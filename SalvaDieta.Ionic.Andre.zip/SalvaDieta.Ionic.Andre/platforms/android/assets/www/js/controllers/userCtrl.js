(function () {
    'use strict';
    angular.module('app').controller('userCtrl', userCtrl);

    userCtrl.$inject = ['$scope', '$rootScope', '$timeout', '$ionicLoading' ]

    function userCtrl($scope, $rootScope, $timeout, $ionicLoading) {                                
            
    };
})();