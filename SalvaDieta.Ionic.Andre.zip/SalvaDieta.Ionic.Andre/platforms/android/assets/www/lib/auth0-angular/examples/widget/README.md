# Widget Example

Using Auth0 Login Widget.

### Running the example
In order to run the example, install `serve` to host static assets:

```sh
npm -g install serve
```

Then execute on the example folder:
```sh
serve
```
and point your browser to [http://localhost:3000/](http://localhost:3000).
